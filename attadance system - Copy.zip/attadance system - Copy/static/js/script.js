
// Smart Attendance System

console.log("EXTERNAL JS FILE LOADED");
let selectedDates = {};
let calendarMonths = {};
async function loadSubjects() {

    const response = await fetch("/get_subjects");

    if (!response.ok) {
        alert("Unable to load subjects!");
        return;
    }

    const subjectData = await response.json();

    const subjects = subjectData.map(item => item.subject_name);
    const attendanceResponse = await fetch("/get_attendance");

if (!attendanceResponse.ok) {
    alert("Unable to load attendance!");
    return;
}

const attendanceData = await attendanceResponse.json();
    const subjectList = document.getElementById("subjectList");

    subjectList.innerHTML = "";

    subjects.forEach((subject, index) => {
       const records = attendanceData.filter(
    record => record.subject === subject
).map(record => ({
    status: record.status,
    date: record.date
}));
        const present = records.filter(r => r.status === "Present").length;
        const absent = records.filter(r => r.status === "Absent").length;
        const total = present + absent;

        const percentage = total === 0
            ? 0
            : Math.round((present / total) * 100);

        const card = document.createElement("div");
        card.className = "dashboard-card";

        card.innerHTML = `
            <h3 class="subject-name">${subject}</h3>
            <div class="attendance-stats">
    <div class="stat-item">
        <span>Total Classes</span>
        <strong>${total}</strong>
    </div>

    <div class="stat-item">
        <span>Present</span>
        <strong>${present}</strong>
    </div>

    <div class="stat-item">
        <span>Absent</span>
        <strong>${absent}</strong>
    </div>
</div>
            <h2 class="attendance-percentage">${percentage}%</h2>
            <small>Attendance</small>
            <div class="attendance-progress">
    <div class="attendance-progress-fill"
         style="width: ${percentage}%;">
    </div>
</div>
<div class="attendance-status ${percentage < 75 ? 'low-attendance' : 'safe-attendance'}">
    ${percentage < 75 ? '⚠ Low Attendance' : '✓ Attendance Safe'}
</div>
            <br><br>

          
<div class="attendance-actions">
    <button class="present-btn"
      onclick="alert('Present button clicked'); markAttendance('${subject}', 'Present')">
        ✓ Present
    </button>

    <button class="absent-btn"
        onclick="markAttendance('${subject}', 'Absent')">
        ✕ Absent
    </button>
</div>

            <br>
       
<button class="delete-icon-btn"
        onclick="deleteSubject(${index})"
        title="Delete Subject">

    <svg width="20" height="20"
         viewBox="0 0 24 24"
         fill="none"
         stroke="currentColor"
         stroke-width="2"
         stroke-linecap="round"
         stroke-linejoin="round">
        <path d="M3 6h18"/>
        <path d="M8 6V4h8v2"/>
        <path d="M19 6l-1 14H6L5 6"/>
        <path d="M10 11v5M14 11v5"/>
    </svg>

</button>


             <br><br>
             <hr>
         <button class="calendar-btn" onclick="toggleCalendar(${index})">
    <span>▦</span> View Calendar
</button>

<div class="attendance-calendar"
     id="calendar-${index}"
     style="display: none;">
</div>
        `;

        subjectList.appendChild(card);
     loadCalendar(subject, index, records);
        
    });
    updateAnalytics(subjects, attendanceData);
}


function changeMonth(subject, direction) {
    if (calendarMonths[subject] === undefined) {
        calendarMonths[subject] = 0;
    }

    calendarMonths[subject] += direction;

    loadSubjects();
}





async function addSubject() {
    const input = document.getElementById("subjectName");
    const subjectName = input.value.trim();

    if (subjectName === "") {
        alert("Please enter a subject name!");
        return;
    }

    const formData = new FormData();
    formData.append("subjectName", subjectName);

    try {
        const response = await fetch("/add_subject", {
            method: "POST",
            body: formData
        });

        if (!response.ok) {
            alert("Unable to add subject!");
            return;
        }

        input.value = "";
        await loadSubjects();

    } catch (error) {
        console.error("ADD SUBJECT ERROR:", error);
        alert("Unable to connect to server!");
        
    }
}



async function deleteSubject(index) {
    const confirmDelete = confirm(
        "Are you sure you want to delete this subject?"
    );

    if (!confirmDelete) return;

    try {
        const response = await fetch("/get_subjects");
        if (!response.ok) {
            alert("Unable to get subjects!");
            return;
        }

        const subjects = await response.json();
        const subject = subjects[index];
        console.log("SUBJECT SELECTED:", subject);

        if (!subject) {
            alert("Subject not found!");
            return;
        }
        console.log("Current URL:", window.location.href);

        const deleteResponse = await fetch("/delete_subject", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                id: subject.id
            })
        });

     const resultText = await deleteResponse.text();

console.log("DELETE STATUS:", deleteResponse.status);
console.log("DELETE RESPONSE:", resultText);

let result;

try {
    result = JSON.parse(resultText);
} catch (error) {
    alert("Server Error! Status: " + deleteResponse.status);
    return;
}

        if (!deleteResponse.ok) {
            alert(result.error || "Unable to delete subject!");
            return;
        }

        await loadSubjects();
        alert("Subject deleted successfully!");

    } catch (error) {
        console.error("DELETE ERROR:", error);
        alert("Delete Error: " + error.message);
    }
}



loadSubjects();


function updateAnalytics(subjects, attendanceData) {
    let totalPresent = 0;
    let totalClasses = 0;

    let highest = null;
    let lowest = null;

    subjects.forEach(subject => {

        const records = attendanceData.filter(
            record => record.subject === subject
        );

        const present = records.filter(
            record => record.status === "Present"
        ).length;

        const absent = records.filter(
            record => record.status === "Absent"
        ).length;

        const total = present + absent;

        const percentage = total === 0
            ? 0
            : Math.round((present / total) * 100);

        totalPresent += present;
        totalClasses += total;

        if (total > 0) {
            if (highest === null || percentage > highest.percentage) {
                highest = { name: subject, percentage };
            }

            if (lowest === null || percentage < lowest.percentage) {
                lowest = { name: subject, percentage };
            }
        }
    });

    const overall = totalClasses === 0
        ? 0
        : Math.round((totalPresent / totalClasses) * 100);

    document.getElementById("totalSubjects").textContent = subjects.length;

    document.getElementById("overallAttendance").textContent = overall + "%";

    document.getElementById("highestAttendance").textContent =
        highest ? highest.name + " (" + highest.percentage + "%)" : "--";

    document.getElementById("lowestAttendance").textContent =
        lowest ? lowest.name + " (" + lowest.percentage + "%)" : "--";
}








    async function markAttendance(subject, status) {

    console.log("Button clicked:", subject, status);

    const date = selectedDates[subject] ||
        new Date().toLocaleDateString("en-CA");

    try {
        const response = await fetch("/mark_attendance", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                subject: subject,
                status: status,
                date: date
            })
        });
        const result = await response.json();

       console.log("Attendance Save Response:", response.status, result);

        if (!response.ok) {
            alert(result.error || "Unable to save attendance!");
            return;
        }

        loadSubjects();

    } catch (error) {
        console.error(error);
        alert("Unable to connect to server!");
    }
}






function toggleCalendar(index) {
    const calendar = document.getElementById("calendar-" + index);
    const button = calendar.previousElementSibling;

    if (calendar.style.display === "none") {
        calendar.style.display = "block";
        button.textContent = "Hide Calendar";
    } else {
        calendar.style.display = "none";
        button.textContent = "View Calendar";
    }
}
function selectDate(subject, date) {
    selectedDates[subject] = date;

    alert("Selected date: " + date);
}
 






function loadCalendar(subject, index, records = []) {
    const calendar = document.getElementById("calendar-" + index);

    if (!calendar) return;

    const today = new Date();

    if (calendarMonths[subject] === undefined) {
        calendarMonths[subject] = 0;
    }

    const viewDate = new Date(
        today.getFullYear(),
        today.getMonth() + calendarMonths[subject],
        1
    );

    const year = viewDate.getFullYear();
    const month = viewDate.getMonth();

    const firstDay = new Date(year, month, 1).getDay();
    const totalDays = new Date(year, month + 1, 0).getDate();

    const attendanceByDate = {};

    records.forEach(record => {
        attendanceByDate[record.date] = record.status;
    });

    let html = `
        <div class="calendar-heading">
            <button onclick="changeMonth('${subject}', -1)">←</button>
            ${viewDate.toLocaleString("default", { month: "long" })} ${year}
            <button onclick="changeMonth('${subject}', 1)">→</button>
        </div>

        <div class="calendar-grid">
            <div>Sun</div><div>Mon</div><div>Tue</div>
            <div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div>
    `;

    for (let i = 0; i < firstDay; i++) {
        html += `<div></div>`;
    }

    for (let day = 1; day <= totalDays; day++) {
        const dateKey =
            `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;

        const status = attendanceByDate[dateKey];

        let className = "calendar-day";

        if (status === "Present") className += " present-day";
        if (status === "Absent") className += " absent-day";

        html += `
            <div class="${className}"
                 onclick="selectDate('${subject}', '${dateKey}')">
                ${day}
            </div>
        `;
    }

    html += `</div>`;
    calendar.innerHTML = html;
}

function toggleCalendar(index) {
    const calendar = document.getElementById("calendar-" + index);
    const button = calendar.previousElementSibling;

    if (calendar.style.display === "none") {
        calendar.style.display = "block";
        button.textContent = "Hide Calendar";
    } else {
        calendar.style.display = "none";
        button.textContent = "View Calendar";
    }
}
function selectDate(subject, date) {
    selectedDates[subject] = date;

    alert("Selected date: " + date);
}










