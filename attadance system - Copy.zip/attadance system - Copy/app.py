from flask import Flask, render_template, request, session, redirect
import sqlite3
import os
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "smart_attendance_secret_2026"

DATABASE = os.path.join(app.root_path, "database.db")


def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db_connection()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fullname TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS subjects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            subject_name TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            subject_name TEXT NOT NULL,
            attendance_date TEXT NOT NULL,
            status TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)
    conn.commit()
    conn.close()



@app.route("/")
def home():
    return render_template("login.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        conn = get_db_connection()

        user = conn.execute("""
            SELECT * FROM users
            WHERE username = ? OR email = ?
        """, (username, username)).fetchone()

        conn.close()

        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            session["fullname"] = user["fullname"]

            return redirect("/dashboard")

        return "Invalid username or password!"

    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":

        fullname = request.form["fullname"]
        email = request.form["email"]
        username = request.form["username"]
        password = request.form["password"]

        password_hash = generate_password_hash(password)

        conn = get_db_connection()

        try:
            conn.execute("""
                INSERT INTO users (fullname, email, username, password_hash)
                VALUES (?, ?, ?, ?)
            """, (fullname, email, username, password_hash))

            conn.commit()
            return "Account created successfully!"

        except sqlite3.IntegrityError:
            return "Email or username already exists!"

        finally:
            conn.close()

    return render_template("register.html")


@app.route("/dashboard")
def dashboard():
    if "user_id" not in session:
        return redirect("/login")

    conn = get_db_connection()

    subjects = conn.execute(
        "SELECT subject_name FROM subjects WHERE user_id = ?",
        (session["user_id"],)
    ).fetchall()

    conn.close()

    return render_template(
        "dashboard.html",
        subjects=subjects
    )

@app.route("/add_subject", methods=["POST"])
def add_subject():
    if "user_id" not in session:
        return redirect("/login")

    subject_name = request.form.get("subjectName", "").strip()

    if subject_name == "":
        return redirect("/dashboard")

    conn = get_db_connection()

    existing = conn.execute(
        "SELECT id FROM subjects WHERE user_id = ? AND subject_name = ?",
        (session["user_id"], subject_name)
    ).fetchone()

    if existing is None:
        conn.execute(
            "INSERT INTO subjects (user_id, subject_name) VALUES (?, ?)",
            (session["user_id"], subject_name)
        )

    conn.commit()
    conn.close()

    return redirect("/dashboard")

print("DELETE ROUTE REGISTERED")
@app.route("/delete_subject", methods=["POST"])
def delete_subject():
    
    if "user_id" not in session:
        return {"error": "Please login"}, 401

    data = request.get_json()
    subject_id = data.get("id")

    if not subject_id:
        return {"error": "Subject ID required"}, 400

    conn = get_db_connection()

    subject = conn.execute(
        "SELECT subject_name FROM subjects WHERE id = ? AND user_id = ?",
        (subject_id, session["user_id"])
    ).fetchone()

    if subject is None:

        conn.close()
        return {"error": "Subject not found"}, 404

    conn.execute(
        "DELETE FROM attendance WHERE user_id = ? AND subject_name = ?",
        (session["user_id"], subject["subject_name"])
    )

    conn.execute(
        "DELETE FROM subjects WHERE id = ? AND user_id = ?",
        (subject_id, session["user_id"])
    )

    conn.commit()
    conn.close()

    return {"message": "Subject deleted successfully"}


@app.route("/get_subjects")
def get_subjects():
    if "user_id" not in session:
        return {"error": "Please login"}, 401

    try:
        conn = get_db_connection()

        subjects = conn.execute(
            "SELECT id, subject_name FROM subjects WHERE user_id = ?",
            (session["user_id"],)
        ).fetchall()

        conn.close()

        return [
            {
                "id": subject["id"],
                "subject_name": subject["subject_name"]
            }
            for subject in subjects
        ]

    except Exception as e:
        print("GET SUBJECTS ERROR:", e)
        return {"error": str(e)}, 500
    
@app.route("/mark_attendance", methods=["POST"])
def save_attendance():
    if "user_id" not in session:
        return {"error": "Please login"}, 401

    data = request.get_json()

    subject = data.get("subject")
    status = data.get("status")
    date = data.get("date")

    if not subject or status not in ["Present", "Absent"] or not date:
        return {"error": "Invalid attendance data"}, 400

    conn = get_db_connection()

    subject_exists = conn.execute(
        "SELECT id FROM subjects WHERE user_id = ? AND subject_name = ?",
        (session["user_id"], subject)
    ).fetchone()

    if subject_exists is None:
        conn.close()
        return {"error": "Subject not found"}, 404

    existing = conn.execute(
        """SELECT id FROM attendance
           WHERE user_id = ? AND subject_name = ? AND attendance_date = ?""",
        (session["user_id"], subject, date)
    ).fetchone()

    if existing:
        conn.execute(
            "UPDATE attendance SET status = ? WHERE id = ?",
            (status, existing["id"])
        )
    else:
        conn.execute(
            """INSERT INTO attendance
               (user_id, subject_name, attendance_date, status)
               VALUES (?, ?, ?, ?)""",
            (session["user_id"], subject, date, status)
        )

    conn.commit()
    conn.close()

    return {"message": "Attendance saved successfully"}

@app.route("/get_attendance")
def get_attendance():
    if "user_id" not in session:
        return {"error": "Please login"}, 401

    conn = get_db_connection()

    records = conn.execute(
        """SELECT subject_name, attendance_date, status
           FROM attendance
           WHERE user_id = ?""",
        (session["user_id"],)
    ).fetchall()

    conn.close()

    return [
        {
            "subject": record["subject_name"],
            "date": record["attendance_date"],
            "status": record["status"]
        }
        for record in records
    ]



@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

if __name__ == "__main__":
    init_db()
    print(app.url_map)
    app.run(debug=True, use_reloader=False)